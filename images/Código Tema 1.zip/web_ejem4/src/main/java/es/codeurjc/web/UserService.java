package es.codeurjc.web;

import org.springframework.stereotype.Component;

@Component
public class UserService {

	public int getNumUsers() {
		return 5;
	}
}
